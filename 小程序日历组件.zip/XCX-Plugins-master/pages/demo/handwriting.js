 Page({
   data: {

   },

   onLoad: function(options) {

   },
   onHnadwritingComplete: function(event) {
     console.log("得到临时文件路径："+event.detail)
   },
 })